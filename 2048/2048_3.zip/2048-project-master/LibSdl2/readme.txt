Include:
$(SolutionDir)LibSdl2\SDL2_ttf-2.0.14\include
$(SolutionDir)LibSdl2\SDL2_mixer-2.0.2\include
$(SolutionDir)LibSdl2\SDL2_image-2.0.3\include
$(SolutionDir)LibSdl2\SDL2-2.0.8\include

From <https://phattrienphanmem123az.com/lap-trinh-game-c-p2/game-cpp-phan-2-cai-dat-project.html>

Lib:
$(SolutionDir)LibSdl2\SDL2-2.0.8\lib\x64
$(SolutionDir)LibSdl2\SDL2_mixer-2.0.2\lib\x64
$(SolutionDir)LibSdl2\SDL2_image-2.0.3\lib\x64
$(SolutionDir)LibSdl2\SDL2_ttf-2.0.14\lib\x64

From <https://phattrienphanmem123az.com/lap-trinh-game-c-p2/game-cpp-phan-2-cai-dat-project.html> 
linker/Input:
SDL2.lib
SDL2main.lib
SDL2_image.lib
SDL2_mixer.lib
SDL2_ttf.lib

From <https://phattrienphanmem123az.com/lap-trinh-game-c-p2/game-cpp-phan-2-cai-dat-project.html> 



