#pragma once
#ifndef GAME_H_
#define GAME_H_
#include "SDL_utils.h"
#include "control.h"
#include "GameOver.h"

void startGame();

#endif 