#pragma once
#ifndef CONTROL_H_
#define CONTROL_H_

#include "commonFunction.h"
#include "SDL_utils.h"

void Up();
void Down();
void Left();
void Right();

#endif 