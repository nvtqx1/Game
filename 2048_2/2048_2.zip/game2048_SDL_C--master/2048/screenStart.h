#pragma once
#ifndef SCREEN_START_H_
#define SCREEN_START_H_

#include <fstream>
#include "SDL_utils.h"
#include "Game.h"

void screenStart();
void rank();
void guide();
void printBest();

#endif