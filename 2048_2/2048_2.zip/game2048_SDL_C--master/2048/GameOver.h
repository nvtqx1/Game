#pragma once
#ifndef GAME_OVER_H_
#define GAME_OVER_H_

#include <fstream>
#include "SDL_utils.h"
#include "screenStart.h"

void gameOver();
void bestScore(int k);

#endif 